
import OpenAI from "openai";

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  try {
    const { prompt, count = 20, type = "words" } = req.body || {};
    if (!prompt) return res.status(400).json({ error: "Вкажи тему." });

    const safeCount = Math.max(5, Math.min(Number(count) || 20, 50));

    const instruction = `
Ти створюєш навчальні флеш-картки.
Поверни ТІЛЬКИ валідний JSON без markdown:
{
  "title": "коротка назва набору",
  "cards": [
    {"q":"лицьова сторона","a":"зворотна сторона"}
  ]
}
Створи рівно ${safeCount} карток.
Тип: ${type}.
Не додавай нумерацію.
Не дублюй картки.
Використовуй мову та напрям перекладу, які просить користувач.
Запит користувача: ${prompt}
`.trim();

    const response = await client.responses.create({
      model: "gpt-5.6-luna",
      input: instruction
    });

    let text = response.output_text?.trim() || "";
    text = text.replace(/^```json\s*/i, "").replace(/^```\s*/i, "").replace(/\s*```$/,"");
    const data = JSON.parse(text);

    if (!data || !Array.isArray(data.cards)) {
      throw new Error("AI повернув неправильний формат");
    }

    data.cards = data.cards
      .filter(c => c && typeof c.q === "string" && typeof c.a === "string")
      .slice(0, safeCount);

    return res.status(200).json(data);
  } catch (err) {
    console.error(err);
    return res.status(500).json({
      error: "Не вдалося створити картки. Перевір OPENAI_API_KEY та спробуй ще раз."
    });
  }
}
